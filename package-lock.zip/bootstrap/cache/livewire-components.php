<?php return array (
  'desa' => 'App\\Http\\Livewire\\Desa',
  'halaman-user' => 'App\\Http\\Livewire\\HalamanUser',
  'info-sawah' => 'App\\Http\\Livewire\\InfoSawah',
  'laporan' => 'App\\Http\\Livewire\\Laporan',
  'pemiliklahan' => 'App\\Http\\Livewire\\Pemiliklahan',
  'peta' => 'App\\Http\\Livewire\\Peta',
  'potensi' => 'App\\Http\\Livewire\\Potensi',
);